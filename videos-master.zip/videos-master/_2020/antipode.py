from manim_imports_ext import *


class NewSceneName(ThreeDScene):
    def construct(self):
        pass
